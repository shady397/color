
# Color picker chrome extension

This project is a chrome extension where you can pick any color from your webpage or browser with your cursor. The implementation is fairly simple, to keep the project scope in check. I wanted to make a project like this to expand my knowledge in javaScript.

Technologies used:

1. HTML
2. CSS 
3. javaScript
4. JSON

## How this extension works?

The idea is simple. You can add this extension to your chrome bowser then use anytime. You just need to click on the extension. This tool can be very useful for web development. Here's video demo of this tool:
https://youtu.be/8Ic-2atUyQ4

When you are writing a code or developing a web sometimes it's so irritating that you can not use proper color. That's why this tool is very useful. It was built with javascript. This is a simple project There's not a lot to talk about or explain about this project. Basically I used javaScript and HTML and css to make this tool. I was able to make this toold because of this cs50 course. I am grateful to Harvard and and David Malan for this. I have learned a lot of things from this course, and I hope that I can continue my computer science and learn new things in upcoming times.

## About cs50

CS50 is a openware course from Havard University and taught by David J. Malan

Introduction to the intellectual enterprises of computer science and the art of programming. This course teaches students how to think algorithmically and solve problems efficiently. Topics include abstraction, algorithms, data structures, encapsulation, resource management, security, and software engineering. Languages include C, Python, and SQL plus students’ choice of: HTML, CSS, and JavaScript (for web development).

Thank you for all CS50.

Where I get CS50 course? https://cs50.harvard.edu/x/2020/

